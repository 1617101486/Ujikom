<?php namespace App\Larabsent\Source;

	class Config
	{
		protected function settings()
		{
			$attribute = [
			
				'appName' => 'Larabsent',
		
			];

			return $attribute;
		}
	}
?>