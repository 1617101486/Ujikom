@extends('layouts')
	
	@section('content')

			<div class="jumbotron">
		        <h1>{{ \Larabsent::config(['appName']) }}</h1>
		        <p>Simple Aplikasi Absensi Pegawai</p>
	      </div>

	@endsection


@stop